#!/bin/bash

brew install freeglut libjpeg libomp openmpi libxmu libxi cmake llvm
cmake -DCMAKE_C_COMPILER="/usr/local/opt/llvm/bin/clang" -DCMAKE_CXX_COMPILER="/usr/local/opt/llvm/bin/clang++" .
make

